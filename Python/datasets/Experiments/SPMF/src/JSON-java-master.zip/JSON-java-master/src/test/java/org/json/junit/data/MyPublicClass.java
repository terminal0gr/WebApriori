package org.json.junit.data;

/**
 * Need a class with some public data members for testing
 */
@SuppressWarnings("boxing")
public class MyPublicClass {
    public Integer publicInt = 42;
    public String publicString = "abc";
}
